#!/usr/bin/env python
 
import sys
import csv
import pandas as pd
import happybase

table_name = 'TableLot3'
connection = happybase.Connection('127.0.0.1', port=9090)
connection.open()
table = connection.table(table_name)

cleaned_data = []

csv_reader = csv.reader(sys.stdin)
next(csv_reader, None)  # Ignorer la première ligne (en-tête)
 
for line in csv_reader:
    cleaned_line = []
    for value in line:
        if value == 'NULL' or value == '':
            # Remplacer par 0 pour les colonnes numériques, sinon par 'vide'
            cleaned_line.append('0' if any(c.isdigit() for c in value) else 'vide')
        else:
            cleaned_line.append(value.replace('"', ''))
    
    cleaned_data.append(cleaned_line)

for line in cleaned_data:

    row_key = line[0]
    
    data = {"cf:{}".format(column_name): str(line[i]).encode('utf-8', errors='surrogateescape') for i, column_name in enumerate(["genrecli", "nomcli", "prenomcli", "cpcli", "villecli", "codcde", "datcde", "timbrecli", "timbrecde", "Nbcolis", "cheqcli", "barchive", "bstock", "codobj", "qte", "Colis", "libobj", "Tailleobj", "Poidsobj", "points", "indispobj", "libcondit", "prixcond", "puobj"], start=1)}

    table.put(row_key, data)