#!/usr/bin/env python
 
import sys
import openpyxl
import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.pyplot as plt
import happybase
 
# Liste pour stocker les lignes triées par score
top_scores = []
top_tri=[]
 
current_key = None
current_quantity_sum = 0
current_ville = None
current_timbrecde = 0
Score = 0
Moyenne = 0
current_nb = 0
 
for line in sys.stdin:
    line = line.strip()
 
    # Essayer de diviser la ligne
    try:
        ID_commande, ville, quantite, timbrecde = line.split('\t', 3)
 
        # Convertir la quantité et le timbrecde en nombres
        quantite = int(quantite)
        timbrecde = float(timbrecde)
        
        
    except ValueError:
        
        continue
 
    # Si la clé (ID_commande) change, imprimer les résultats pour la clé précédente
    if current_key and current_key != ID_commande:
        
        # Ajouter les colonne supplémentaire (Score,Moyenne)
        Score = current_quantity_sum + current_timbrecde
        Moyenne = current_quantity_sum/current_nb
        top_scores.append((current_key, current_ville, current_quantity_sum,Score, Moyenne))
        
        # Réinitialiser les variables pour la nouvelle clé
        
        current_key = ID_commande
        current_quantity_sum = 0
        current_ville = None
        current_timbrecde = 0
        current_nb = 0
        
        # Mettre à jour les agrégations
    
    current_nb += 1
    current_key = ID_commande
    current_quantity_sum += quantite
    current_ville = ville
    current_timbrecde = max(current_timbrecde, timbrecde)
 
# Ajouter la colonne supplémentaire (quantite + timbrecde) pour la dernière clé
if current_key:
    Score = current_quantity_sum + current_timbrecde
    Moyenne = current_quantity_sum / current_nb
    top_scores.append((current_key, current_ville, current_quantity_sum,Score, Moyenne))
    
 
# Trier la liste par score dans l'ordre décroissant
top_scores.sort(key=lambda x: x[3], reverse=True)
 
# Imprimer les 100 premières lignes du top_scores
for i, row in enumerate(top_scores[:100]):
    top_tri.append((row[0], row[1], row[2], row[3], row[4]))
    print('{}\t{}\t{}\t{}\t{}'.format(row[0], row[1], row[2], row[3], row[4]))


# Créer un DataFrame afin de sortir les X% aléatoires voulus
df = pd.DataFrame(top_tri)
pourcentage = 5

taille_sample = int(len(df)*(pourcentage/100))
echantillon_aleatoire = df.sample(n=taille_sample,random_state=30)

entetes = ["Code_cde","Ville","Quantite","Score","Moyenne"]

# Créer un DataFrame tiré des X% précédents afin de donner l'entête
df1 = pd.DataFrame(echantillon_aleatoire)
df1.columns = entetes

print(echantillon_aleatoire)


# Créer un nouveau classeur Excel et ajouter une feuille de calcul
excel_chemin = '/datavolume1/top_resultats_lot_2.xlsx'

df1.to_excel(excel_chemin, index=False, header = True)

plt.figure()

# Créer le graphe pie
plt.pie(echantillon_aleatoire['Score'], labels=echantillon_aleatoire['Ville'], autopct='%1.1f%%', startangle=140, textprops={'fontsize':8})
plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
plt.title("Répartition du score par ville")

# Enregistrer le graphe au format PDF

output_pdf_file = '/datavolume1/resultat_lot2.pdf'
with PdfPages(output_pdf_file) as pdf:
    pdf.savefig()  # Sauvegarder le graphe dans le fichier PDF
