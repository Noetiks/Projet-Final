#!/usr/bin/env python
 
import sys
import openpyxl
import pandas as pd
 
# Liste pour stocker les lignes triées par score
top_scores = []
top_tri=[]
 
current_key = None
current_quantity_sum = 0
current_ville = None
current_timbrecde = 0
Score = 0
 
for line in sys.stdin:
    line = line.strip()
 
    # Essayer de diviser la ligne
    try:
        ID_commande, ville, quantite, timbrecde = line.split('\t', 3)
 
        # Convertir la quantité et le timbrecde en nombres
        quantite = int(quantite)
        timbrecde = float(timbrecde)
    except ValueError:
        
        continue
 
    # Si la clé (ID_commande) change, imprimer les résultats pour la clé précédente
    if current_key and current_key != ID_commande:
        # Ajouter la colonne supplémentaire (quantite + timbrecde)
        Score = current_quantity_sum + current_timbrecde
        top_scores.append((current_key, current_ville, current_quantity_sum, current_timbrecde, Score))
 
        # Réinitialiser les variables pour la nouvelle clé
        current_key = ID_commande
        current_quantity_sum = 0
        current_ville = None
        current_timbrecde = 0
 
    # Mettre à jour les agrégations
    current_key = ID_commande
    current_quantity_sum += quantite
    current_ville = ville
    current_timbrecde = max(current_timbrecde, timbrecde)
 
# Ajouter la colonne supplémentaire (quantite + timbrecde) pour la dernière clé
if current_key:
    Score = current_quantity_sum + current_timbrecde
    top_scores.append((current_key, current_ville, current_quantity_sum, current_timbrecde, Score))
 
# Trier la liste par score dans l'ordre décroissant
top_scores.sort(key=lambda x: x[4], reverse=True)
 
# Imprimer les 100 premières lignes du top_scores
for i, row in enumerate(top_scores[:100]):
    top_tri.append((row[0], row[1], row[2], row[3], row[4]))
    print('{}\t{}\t{}\t{}\t{}'.format(row[0], row[1], row[2], row[3], row[4]))

# Créer un nouveau classeur Excel et ajouter une feuille de calcul

df = pd.DataFrame(top_tri)
entetes = ["Code_cde","Ville","Quantite","Timbrecde","Score"]
df.columns = entetes

excel_chemin = '/datavolume1/top_resultats_lot_1.xlsx'

df.to_excel(excel_chemin, index=False, header = True)
