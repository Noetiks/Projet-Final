#!/usr/bin/env python

import sys
import csv
from datetime import datetime

csv_reader = csv.reader(sys.stdin)
next(csv_reader, None)

for row in csv_reader:

    # S'assurer qu'il y a suffisamment de colonnes dans la ligne
    if len(row) >=8:
        # Extraire les champs pertinents
        datcde = row[7].replace('"', '')
        cpcli = row[4].replace('"', '')
        id_cde = row[6].replace('"', '')
        quantite = row[15].replace('"', '')
        timbrecde = row[9].replace('"', '')
        ville = row[5].replace('"', '')
        timbrecli = row[8].replace('"', '')

        try:
            # Convertir la date en objet datetime
            date_object = datetime.strptime(datcde, '%Y-%m-%d %H:%M:%S')

            # Extraire l'année et le département du code postal
            year = date_object.year
            department = cpcli[:2]
            

            # Filtrer les données
            if 2011 <= year <= 2016 and department in ('22', '49', '53') and timbrecli in ('0','NULL',''):
                # Sortie du mappage avec la clé (année, département) et la ligne complète comme valeur
                print('{}\t{}\t{}\t{}'.format(id_cde,ville,quantite,timbrecde))
        except ValueError as e:
            # Afficher les dates incorrectes pour débogage
            
            continue

         

'''
hadoop jar hadoop-streaming-2.7.2.jar -file mapper.py -mapper "python3 mapper.py" -file reducer.py -reducer "python3 reducer.py" -input input/word.txt -output output01
'''