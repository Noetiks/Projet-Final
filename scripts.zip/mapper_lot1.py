#!/usr/bin/env python

import sys
import csv
from datetime import datetime

for line in sys.stdin:
    line = line.strip()
    # Ignorer l'en-tête du CSV
    if line.startswith('"codcli"'):
        continue

    # Diviser la ligne en valeurs
    values = list(csv.reader([line]))[0]

    # S'assurer qu'il y a suffisamment de colonnes dans la ligne
    if len(values) >=8:
        # Extraire les champs pertinents
        datcde = values[7].replace('"', '')
        cpcli = values[4].replace('"', '')

        try:
            # Convertir la date en objet datetime
            date_object = datetime.strptime(datcde, '%Y-%m-%d %H:%M:%S')

            # Extraire l'année et le département du code postal
            year = date_object.year
            department = cpcli[:2]

            # Filtrer les données
            if 2006 <= year <= 2010 and department in ('53', '61', '28'):
                # Sortie du mappage avec la clé (année, département) et la ligne complète comme valeur
                print('{}\t{}\t{}'.format(year, department, line))
        except ValueError as e:
            # Afficher les dates incorrectes pour débogage
            print(f"Erreur de conversion de la date '{datcde}': {e}")
            continue

         

'''
hadoop jar hadoop-streaming-2.7.2.jar -file mapper.py -mapper "python3 mapper.py" -file reducer.py -reducer "python3 reducer.py" -input input/word.txt -output output01
'''